<template>
  <footer id="contact" class="bg-copper-900 text-white py-10 px-4 mt-10">
      <div class="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
        <div>
          <span class="font-bold text-xl">NoteZapp</span>
          <span class="ml-4 text-copper-400">© 2025</span>
        </div>
        <div class="flex gap-10">
          <a href="#features" class="hover:text-copper-400">Fonctionnalités</a>
          <a href="#about" class="hover:text-copper-400">À propos</a>
          <a href="#contact" class="hover:text-copper-400">Contact</a>
        </div>
      </div>
    </footer>
</template>
